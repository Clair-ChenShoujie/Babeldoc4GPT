"""Local HTTP compatibility test. Does not call a paid/external model."""
import json
import os
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PLUGIN = Path(__file__).resolve().parents[1] / "skills/translate-pdf-cloud"
sys.path[:0] = [str(PLUGIN / "scripts"), str(PLUGIN / "vendor")]
from worker import make_settings


class ApiAdapterTest(unittest.TestCase):
    def test_existing_openai_compatible_api(self):
        seen = []

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                seen.append((self.path, json.loads(self.rfile.read(int(self.headers["Content-Length"])))))
                body = json.dumps({"id": "local-fixture", "object": "chat.completion", "created": 0, "model": "local-fixture", "choices": [{"index": 0, "message": {"role": "assistant", "content": "你好"}, "finish_reason": "stop"}], "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        os.environ["BABELDOC_LOCAL_TEST_KEY"] = "local-fixture-only"
        previous_proxy = {k: os.environ.get(k) for k in ("NO_PROXY", "no_proxy")}
        for k in previous_proxy:
            os.environ[k] = "127.0.0.1,localhost"
        try:
            from pdf2zh_next.translator.translator_impl.openai import OpenAITranslator
            settings = make_settings({"mode": "api", "source_language": "en", "target_language": "zh", "api": {"model": "local-fixture", "base_url": f"http://127.0.0.1:{server.server_port}/v1", "key_env": "BABELDOC_LOCAL_TEST_KEY"}}, Path.cwd())
            translator = OpenAITranslator(settings, None)
            self.assertEqual(translator.do_llm_translate("Translate Hello to Chinese"), "你好")
            self.assertEqual(translator.do_translate("Hello"), "你好")
            self.assertEqual(len(seen), 2)
            self.assertTrue(all(p == "/v1/chat/completions" for p, _ in seen))
            self.assertEqual(seen[0][1]["model"], "local-fixture")
            self.assertEqual(seen[0][1]["messages"][0]["content"], "Translate Hello to Chinese")
            translator.client.close()
        finally:
            server.shutdown()
            server.server_close()
            os.environ.pop("BABELDOC_LOCAL_TEST_KEY", None)
            for k, value in previous_proxy.items():
                if value is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = value


if __name__ == "__main__":
    unittest.main()

