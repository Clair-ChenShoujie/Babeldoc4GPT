"""Linux integration: killing an advance controller must not leave its worker."""
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
SKILL = PACKAGE / "skills/translate-pdf-cloud"
sys.path[:0] = [str(SKILL / "vendor"), str(SKILL / "scripts")]
import service
import store

assert sys.platform == "linux"
root = Path(sys.argv[1]).resolve()
root.mkdir(parents=True, exist_ok=True)
os.environ["BABELDOC_WORK_DATA"] = str(root / "data")
job = service.create_job(str(PACKAGE / "tests/sample.pdf"))
folder = store.job_dir(job["job_id"])
args = root / "advance.json"
args.write_text(json.dumps({"job_id": job["job_id"], "max_seconds": 120}))
with open(root / "controller.log", "w") as log:
    parent = subprocess.Popen([sys.executable, str(SKILL / "scripts/cli.py"), "advance", "--args", str(args)], stdout=log, stderr=log)
    try:
        deadline = time.monotonic() + 30
        while not store.is_live(folder):
            if time.monotonic() > deadline or parent.poll() is not None:
                raise RuntimeError("Worker did not acquire its lock")
            time.sleep(0.05)
        # Allow the worker's parent-death guard (before its lock) to be active.
        parent.kill()
        parent.wait(timeout=5)
        deadline = time.monotonic() + 5
        while store.is_live(folder) and time.monotonic() < deadline:
            time.sleep(0.05)
        assert not store.is_live(folder), "Orphan worker retained its OS lock"
        print(json.dumps({"parent_death_cleanup": "passed", "status": service.status(job["job_id"])["status"]}))
    finally:
        if parent.poll() is None:
            parent.kill()
            parent.wait()
