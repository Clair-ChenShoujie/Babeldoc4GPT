"""Re-render an already translated fixture, checking IL cache equivalence."""
import json
import os
import subprocess
import sys
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
SKILL = PACKAGE / "skills/translate-pdf-cloud"
sys.path[:0] = [str(SKILL / "vendor"), str(SKILL / "scripts")]
import store
import pymupdf

root = Path(sys.argv[1]).resolve()
os.environ["BABELDOC_WORK_DATA"] = str(root / "jobs-data")
report = json.loads((root / "verification.json").read_text())
folder = store.job_dir(report["job_id"])
assert store.metadata(folder)["status"] == "completed"
assert list((folder / "phase-cache").glob("*.json")), "No pre-translation IL checkpoint"


def signature():
    result = []
    for item in store.metadata(folder)["artifacts"]:
        if item["path"].endswith(".pdf"):
            with pymupdf.open(item["path"]) as doc:
                result.append([(tuple(p.rect), p.get_text()) for p in doc])
    return result


before = signature()
with open(root / "cached-render.log", "w", encoding="utf-8") as log:
    subprocess.run([sys.executable, str(SKILL / "scripts/cli.py"), "worker", report["job_id"]], stdout=log, stderr=log, timeout=180, check=True)
after = signature()
assert store.metadata(folder)["status"] == "completed", store.metadata(folder)
assert before == after, "Cached render changed PDF page geometry or text"
assert "Cloud pre-translation IL cache hit" in (root / "cached-render.log").read_text()
print(json.dumps({"cached_render": "passed", "page_text_and_geometry_unchanged": True}))
