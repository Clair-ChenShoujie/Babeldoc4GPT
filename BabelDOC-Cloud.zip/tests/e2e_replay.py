"""Regression replay ONLY for tests/sample.pdf; no production translation code."""
import json
import os
import sys
import time
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
SKILL = PACKAGE / "skills/translate-pdf-cloud"
sys.path[:0] = [str(SKILL / "vendor"), str(SKILL / "scripts")]
import service
import store
import checkpoint

data = Path(sys.argv[1]).resolve()
data.mkdir(parents=True, exist_ok=True)
os.environ["BABELDOC_WORK_DATA"] = str(data / "jobs-data")
responses = json.loads((PACKAGE / "tests/fixture-responses.json").read_text(encoding="utf-8"))
exact = {x["prompt"]: x["response"] for x in responses}
paragraphs = {}
for item in responses:
    c = store.contract_for(item["prompt"], item["kind"])
    if c["format"] == "paragraphs":
        translated = json.loads(item["response"])
        paragraphs.update({a["input"]: b["output"] for a, b in zip(c["entries"], translated)})

job = service.create_job(str(PACKAGE / "tests/sample.pdf"), pdf_options={"watermark_output_mode": "no_watermark"}, translation_options={"save_auto_extracted_glossary": True})
job_id = job["job_id"]
print(json.dumps({"created": job_id}), flush=True)
steps = []
restored_once = False
started = time.monotonic()
for iteration in range(12):
    value = service.advance(job_id, max_seconds=180)
    steps.append({"status": value["job"]["status"], "seconds": value.get("step_seconds"), "requests": len(value["requests"]), "worker_alive": value["job"]["worker_alive"]})
    print(json.dumps(steps[-1]), flush=True)
    assert not value["job"]["worker_alive"], "A child worker escaped the bounded step"
    if value["job"]["status"] == "completed":
        exported = service.export_files(job_id, str(data / "outputs"))
        import pymupdf
        pdfs = [x for x in exported["files"] if x["path"].endswith(".pdf")]
        assert len(pdfs) == 2
        for artifact in pdfs:
            with pymupdf.open(artifact["path"]) as doc:
                assert doc.page_count == 2
                text = "".join(page.get_text() for page in doc)
                assert "文档" in text and "恢复" in text and "94%" in text, text
        report = {"success": True, "job_id": job_id, "steps": steps, "checkpoint_restored": restored_once, "seconds": round(time.monotonic()-started, 2), "artifacts": exported["files"], "validation_environment": "Linux regression replay; not a claim of ChatGPT website execution"}
        (data / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False), flush=True)
        break
    if not value["requests"]:
        raise RuntimeError(json.dumps(value["job"]))
    results = []
    for request in value["requests"]:
        prompt = request["prompt"]
        response = exact.get(prompt)
        if response is None:
            c = store.contract_for(prompt, request["kind"])
            if c["format"] == "paragraphs" and all(x["input"] in paragraphs for x in c["entries"]):
                response = json.dumps([{"id": x["id"], "output": paragraphs[x["input"]]} for x in c["entries"]], ensure_ascii=False)
            elif c["format"] == "text" and c["input"] in paragraphs:
                response = paragraphs[c["input"]]
            else:
                (data / "unmatched-request.json").write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")
                raise RuntimeError("Fixture changed; inspect unmatched-request.json. Never fabricate a response.")
        results.append({"request_id": request["request_id"], "response": response})
    service.submit_results(job_id, results)
    if not restored_once:
        saved = checkpoint.export_checkpoint(job_id, str(data / "migration.zip"))
        imported = checkpoint.import_checkpoint(saved["checkpoint"])
        job_id = imported["job_id"]
        restored_once = True
        print(json.dumps({"restored_as": job_id}), flush=True)
else:
    raise RuntimeError("Too many steps")
