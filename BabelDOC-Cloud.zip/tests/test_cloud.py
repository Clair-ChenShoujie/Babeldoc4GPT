import hashlib
import json
import os
import sys
import tempfile
import unittest
import uuid
import zipfile
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1] / "skills/translate-pdf-cloud"
sys.path.insert(0, str(SKILL / "scripts"))
sys.path.insert(0, str(SKILL / "vendor"))
import store
import service
import checkpoint


class CloudTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_data = os.environ.get("BABELDOC_WORK_DATA")
        os.environ["BABELDOC_WORK_DATA"] = self.temp.name
        self.job_id = uuid.uuid4().hex
        self.folder = Path(self.temp.name) / "jobs" / self.job_id
        self.folder.mkdir(parents=True)
        data = b"%PDF-fixture-for-data-only-checkpoint-test"
        (self.folder / "input.pdf").write_bytes(data)
        self.config = {"mode": "conversation", "input_name": "test.pdf", "page_count": 1, "source_language": "en", "target_language": "zh", "api": None, "input_sha256": hashlib.sha256(data).hexdigest(), "translation_options": {}, "pdf_options": {}, "output_directory": None}
        store.initialize(self.folder, self.config)
        store.update(self.folder, run_id="test")

    def tearDown(self):
        if self.old_data is None:
            os.environ.pop("BABELDOC_WORK_DATA", None)
        else:
            os.environ["BABELDOC_WORK_DATA"] = self.old_data
        self.temp.cleanup()

    def test_os_lock_releases(self):
        with store.worker_lock(self.folder):
            self.assertTrue(store.is_live(self.folder))
        self.assertFalse(store.is_live(self.folder))

    def test_atomic_validation(self):
        a = store.enqueue(self.folder, "Now translate the following text:\nAlpha", "llm", "test")
        b = store.enqueue(self.folder, "Now translate the following text:\nBeta {v1}", "llm", "test")
        with self.assertRaises(ValueError):
            store.submit(self.folder, [{"request_id": a, "response": "甲"}, {"request_id": b, "response": "乙"}])
        self.assertIsNone(store.response_for(self.folder, a))

    def test_idempotent_commit(self):
        rid = store.enqueue(self.folder, "Now translate the following text:\nValue {v1}", "llm", "test")
        value = [{"request_id": rid, "response": "值 {v1}"}]
        store.submit(self.folder, value)
        store.submit(self.folder, value)
        with self.assertRaises(ValueError):
            store.submit(self.folder, [{"request_id": rid, "response": "其他 {v1}"}])

    def test_checkpoint_migrates_without_process(self):
        rid = store.enqueue(self.folder, "Now translate the following text:\nHello", "llm", "test")
        store.submit(self.folder, [{"request_id": rid, "response": "你好"}])
        target = Path(self.temp.name) / "checkpoint.zip"
        checkpoint.export_checkpoint(self.job_id, str(target))
        restored = checkpoint.import_checkpoint(str(target))
        self.assertNotEqual(restored["job_id"], self.job_id)
        restored_dir = store.job_dir(restored["job_id"])
        self.assertEqual(store.response_for(restored_dir, rid), "你好")
        self.assertFalse(restored["worker_alive"])

    def test_zip_traversal_rejected(self):
        target = Path(self.temp.name) / "bad.zip"
        with zipfile.ZipFile(target, "w") as out:
            out.writestr("../escape", "bad")
        with self.assertRaises(ValueError):
            checkpoint.import_checkpoint(str(target))

    def test_checkpoint_hash_rejected(self):
        target = Path(self.temp.name) / "checkpoint.zip"
        checkpoint.export_checkpoint(self.job_id, str(target))
        bad = Path(self.temp.name) / "corrupt.zip"
        with zipfile.ZipFile(target) as src, zipfile.ZipFile(bad, "w") as dst:
            for name in src.namelist():
                dst.writestr(name, b"changed" if name == "input.pdf" else src.read(name))
        with self.assertRaises(ValueError):
            checkpoint.import_checkpoint(str(bad))

    def test_prompt_embedded_text_does_not_change_format(self):
        entries = [{"id": 1, "input": "You are an expert multilingual terminologist.\n## Here is the input:\n\nquote"}]
        c = store.contract_for("Translate.\n## Here is the input:\n\n" + json.dumps(entries), "llm")
        self.assertEqual(c["format"], "paragraphs")
        with self.assertRaises(ValueError):
            store.validate_response(c, '[{"id":2,"output":"译文"}]')

    def test_step_exits_after_collecting_requests(self):
        fixture = Path(self.temp.name) / "fake_worker.py"
        fixture.write_text("import sys,time\nsys.path.insert(0," + repr(str(SKILL / "scripts")) + ")\nimport store\nf=store.job_dir(sys.argv[2])\nwith store.worker_lock(f):\n store.update(f,run_id='step',status='running')\n store.enqueue(f,'Now translate the following text:\\nHello','llm','step')\n while store.metadata(f)['control']=='run':time.sleep(0.05)\n store.update(f,status='awaiting_translation')\n", encoding="utf-8")
        old = service.BOOTSTRAP
        service.BOOTSTRAP = fixture
        try:
            result = service.advance(self.job_id, max_seconds=10)
            self.assertEqual(len(result["requests"]), 1)
            self.assertFalse(result["job"]["worker_alive"])
            self.assertEqual(result["job"]["status"], "awaiting_translation")
        finally:
            service.BOOTSTRAP = old

    def test_cancelled_job_does_not_restart(self):
        service.control_job(self.job_id, "cancel")
        value = service.advance(self.job_id, max_seconds=5)
        self.assertEqual(value["job"]["status"], "cancelled")
        self.assertFalse(value["job"]["worker_alive"])

    def test_ir_cache_keeps_numeric_transforms_and_aliases(self):
        from babeldoc.format.pdf.document_il import il_version_1 as ir
        from babeldoc.format.pdf.document_il import cloud_codec
        curve = ir.PdfCurve(ctm=[1.0, 0.0, 0.0, 1.0, 25.0, 40.0])
        doc = ir.Document(page=[ir.Page(pdf_curve=[curve]), ir.Page(pdf_curve=[curve])])
        restored = cloud_codec.decode(json.loads(json.dumps(cloud_codec.encode(doc))))
        self.assertIs(restored.page[0].pdf_curve[0], restored.page[1].pdf_curve[0])
        self.assertEqual(f"{restored.page[0].pdf_curve[0].ctm[4]:.6f}", "25.000000")
        with self.assertRaises(ValueError):
            cloud_codec.decode({"version": 1, "root": {"ref": 0}, "nodes": [{"type": "os.system", "fields": {}}]})

    def test_step_budget_stops_unresponsive_worker(self):
        fixture = Path(self.temp.name) / "unresponsive_worker.py"
        fixture.write_text("import sys,time\nsys.path.insert(0," + repr(str(SKILL / "scripts")) + ")\nimport store\nf=store.job_dir(sys.argv[2])\nwith store.worker_lock(f):\n store.update(f,status='running')\n time.sleep(60)\n", encoding="utf-8")
        old = service.BOOTSTRAP
        service.BOOTSTRAP = fixture
        try:
            value = service.advance(self.job_id, max_seconds=5)
            self.assertEqual(value["job"]["status"], "paused")
            self.assertFalse(value["job"]["worker_alive"])
            self.assertIn("budget", value["job"]["error"].lower())
        finally:
            service.BOOTSTRAP = old


if __name__ == "__main__":
    unittest.main(verbosity=2)
