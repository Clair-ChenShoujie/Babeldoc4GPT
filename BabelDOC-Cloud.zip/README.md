# BabelDOC 云端 PDF 翻译

面向 ChatGPT 官网 Work 的纯沙箱实现。默认由当前对话模型完成翻译，原 BabelDOC
引擎完成解析、公式处理和排版。无需运行你的电脑、外部服务器、浏览器扩展或翻译 API。

## 导入到官网

1. 下载同目录的 `BabelDOC-Cloud.zip`。
2. 在官网插件页面使用你确认存在的 ZIP／文件导入入口，导入该文件。
3. 安装后，在一个新的云端 Work 聊天中选择 **BabelDOC 云端 PDF 翻译**。
4. 上传 PDF，发送：

   > 把这份 PDF 翻译成中文，保留公式和版式，输出中文和双语 PDF。请在云沙箱中实际执行，使用当前对话翻译，不调用额外模型 API。

第一次运行会在任务目录中安装 Linux Python 依赖并准备排版模型和字体。
这不是模型推理 API 调用，不需要翻译 API Key。

如果官网没有成功加载工作流，可把 ZIP 和 PDF 一起上传到 Work，再使用
`开始使用.txt` 中的完整提示词执行同一套代码。这是单任务的运行入口，
不应被当成“账号插件已安装”的证据。

## 包含的实现

- BabelDOC 0.6.2 与 PDFMathTranslate Next 2.9.0 源码。
- 单个 Skill 工作流、Python 依赖安装器、环境诊断和 JSON 命令入口。
- 当前对话翻译队列、术语提取、段落／公式／样式校验。
- 有执行时限的引擎步骤，步骤结束后工作进程退出。
- Linux 父进程终止保护，避免执行工具中断后遗留等待进程。
- 解析后的版面缓存、已提交译文缓存、可跨沙箱导入的进度 ZIP。
- 中文／目标语言 PDF、双语 PDF、术语表导出。
- 原有 PDF 选项，以及用户明确选择时使用的 OpenAI 兼容 API 模式。

## 安装包与资源

`BabelDOC-Cloud.zip` 不包含 Windows 可执行文件，也不把几百 MB 的模型和字体
塞进插件导入包。首次使用时由沙箱下载依赖与所需资源。

如果沙箱可以下载 Python 包但无法访问字体／排版模型源，可另外把
`BabelDOC-Cloud-assets.zip` 作为附件上传。它是离线资源，不是第二个插件。
按工作流解压并设置 `BABELDOC_ASSETS` 后可复用。

完全无网络的沙箱还需要匹配 Linux/Python 版本的依赖 wheels；离线资源包不包含
这些二进制依赖。安装器支持 `--wheelhouse` 指定已有的离线依赖目录。

## 断点续传

说“暂停并保存进度包”，工作流会导出包含原 PDF、译文、术语表和设置的 ZIP。
换一个 Work 沙箱后上传该进度包并要求继续即可。不要依赖沙箱文件永远保留。
缓存版面只在当前任务中复用；跨沙箱恢复会重新解析原 PDF，但复用匹配的译文。

## 执行接口

脚本位于 `skills/translate-pdf-cloud/scripts/`。所有参数通过 UTF-8 JSON 文件传入：

```text
python3 scripts/setup.py --runtime /实际任务目录/.babeldoc-runtime
返回的Python scripts/cli.py COMMAND --data /实际任务目录/jobs --args /实际参数文件.json
```

命令包括 `health`、`prepare_assets`、`get_options`、`create_job`、`advance`、
`get_batch`、`submit_results`、`get_status`、`control_job`、`export_files`、
`export_checkpoint`、`import_checkpoint`、`list_jobs`。

Python 3.12 使用完整依赖锁文件；其他支持版本使用固定直接依赖。
任务数据、配置和缓存写入任务目录，不要求插件目录或用户主目录可写。

## 验证与边界

详见 `验证记录.md` 和 `tests/`。Linux 测试不等同于已经在你的官网账号完成运行。
不同 Work 沙箱的网络、内存、执行时间和插件导入限制仍以实际环境为准。
原版对复杂扫描件、字体和段落分割的局限仍然存在。

## 源码变更和许可证

`I:\BabelDOC` 与此前桌面插件没有修改。云端源码副本除适配器外有以下兼容修改：

1. pdf2zh_next 高层入口改为延迟导入，保留原公开名称。
2. BabelDOC 和 pdf2zh_next 的缓存／配置目录可通过环境变量指向任务目录。
3. BabelDOC 原翻译前处理阶段可保存／读取保留类型与对象引用的 JSON 版面缓存；缓存损坏时重新解析。

引擎的翻译后排版和 PDF 生成流程继续使用原实现。新增代码采用 AGPL-3.0-or-later；
上游项目保留各自许可证。字体和模型沿用原项目资源来源及各自许可证。

参考：
- https://developers.openai.com/plugins/build/skills
- https://developers.openai.com/plugins/deploy/submission-errors
- https://learn.chatgpt.com/docs/enterprise/chatgpt-work-cloud-security
