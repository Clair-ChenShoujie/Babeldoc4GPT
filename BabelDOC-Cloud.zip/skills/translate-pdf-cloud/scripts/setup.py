"""Install isolated Linux runtime; never modifies the sandbox's system Python."""
import argparse
import hashlib
import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UV_VERSION = "0.9.26"


def doctor():
    memory = None
    if Path("/proc/meminfo").exists():
        memory = int(Path("/proc/meminfo").read_text().split("MemTotal:")[1].split()[0]) // 1024
    for path in (Path("/sys/fs/cgroup/memory.max"), Path("/sys/fs/cgroup/memory/memory.limit_in_bytes")):
        if path.exists():
            limit = path.read_text().strip()
            if limit.isdigit():
                memory = min(memory or int(limit)//1048576, int(limit)//1048576)
    return {"os": platform.system(), "architecture": platform.machine(), "python": platform.python_version(), "effective_memory_mb": memory, "disk_free_mb": shutil.disk_usage(ROOT).free // (1024 * 1024), "uv_available": bool(shutil.which("uv")), "cloud_required": "Linux x86_64 with Python 3.11-3.13 (tested Python 3.12); package and asset installation require network or offline bundles", "actual_cloud_test": "This command reports only the environment in which it runs."}


def fetch(url, destination):
    with urllib.request.urlopen(url, timeout=60) as response, open(destination, "wb") as output:
        shutil.copyfileobj(response, output)


def get_uv(runtime):
    existing = shutil.which("uv")
    if existing:
        return existing
    target = runtime / "bootstrap" / "uv"
    if target.exists():
        return str(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(f"https://pypi.org/pypi/uv/{UV_VERSION}/json", timeout=60) as response:
        metadata = json.load(response)
    candidates = [x for x in metadata["urls"] if "manylinux" in x["filename"] and "x86_64" in x["filename"] and x["filename"].endswith(".whl")]
    if len(candidates) != 1:
        raise RuntimeError("Could not identify the pinned Linux uv wheel")
    item = candidates[0]
    wheel = target.parent / item["filename"]
    fetch(item["url"], wheel)
    if hashlib.sha256(wheel.read_bytes()).hexdigest() != item["digests"]["sha256"]:
        raise RuntimeError("uv bootstrap checksum mismatch")
    with zipfile.ZipFile(wheel) as archive:
        names = [n for n in archive.namelist() if n.endswith("/uv")]
        if len(names) != 1:
            raise RuntimeError("uv wheel does not contain one executable")
        target.write_bytes(archive.read(names[0]))
    target.chmod(0o755)
    wheel.unlink()
    return str(target)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", default=str(ROOT / ".runtime"))
    parser.add_argument("--doctor", action="store_true")
    parser.add_argument("--wheelhouse", help="Optional offline wheel directory")
    args = parser.parse_args()
    print(json.dumps(doctor(), ensure_ascii=False), flush=True)
    if args.doctor:
        return
    if platform.system() != "Linux" or platform.machine() != "x86_64":
        raise RuntimeError("This cloud package targets Linux x86_64; use the desktop package on Windows")
    runtime = Path(args.runtime).resolve()
    runtime.mkdir(parents=True, exist_ok=True)
    uv = get_uv(runtime)
    env = os.environ.copy()
    env["UV_PYTHON_INSTALL_DIR"] = str(runtime / "python-downloads")
    env["UV_CACHE_DIR"] = str(runtime / "uv-cache")
    python = sys.executable if (3, 11) <= sys.version_info[:2] <= (3, 13) else "3.12"
    venv = runtime / "venv"
    if not (venv / "bin/python").exists():
        subprocess.run([uv, "venv", str(venv), "--python", python], check=True, env=env)
    version = subprocess.check_output([str(venv / "bin/python"), "-c", "import sys;print('%s.%s'%sys.version_info[:2])"], text=True).strip()
    locked = ROOT / "requirements-linux-py312.lock"
    requirements = locked if version == "3.12" and locked.exists() else ROOT / "requirements.txt"
    command = [uv, "pip", "install", "--python", str(venv / "bin/python"), "-r", str(requirements)]
    if args.wheelhouse:
        command += ["--no-index", "--find-links", str(Path(args.wheelhouse).resolve())]
    subprocess.run(command, check=True, env=env)
    print(json.dumps({"ready": True, "python": str(venv / "bin/python"), "cli": str(ROOT / "scripts/cli.py")}), flush=True)


if __name__ == "__main__":
    main()
