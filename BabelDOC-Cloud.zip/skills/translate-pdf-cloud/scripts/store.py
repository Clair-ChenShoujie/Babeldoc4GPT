"""Durable conversation-to-BabelDOC request queue; no model API calls."""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import time
from collections import Counter
from contextlib import contextmanager
from pathlib import Path


def data_root():
    return Path(os.environ.get("BABELDOC_WORK_DATA", str(Path.cwd() / "babeldoc-jobs"))).resolve()


def job_dir(job_id):
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise ValueError("Invalid job ID")
    p = data_root() / "jobs" / job_id
    if not (p / "job.sqlite3").is_file():
        raise ValueError("Unknown job ID")
    return p


@contextmanager
def connect(folder):
    db = sqlite3.connect(Path(folder) / "job.sqlite3", timeout=30)
    db.row_factory = sqlite3.Row
    try:
        db.execute("PRAGMA journal_mode=WAL")
        yield db
        db.commit()
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()


def initialize(folder, config):
    with connect(folder) as db:
        db.executescript("""
        CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE requests (
            id TEXT PRIMARY KEY, kind TEXT NOT NULL, prompt TEXT NOT NULL,
            contract TEXT NOT NULL, response TEXT, created REAL NOT NULL,
            run_id TEXT NOT NULL);
        """)
        for k, v in {"config": config, "status": "created", "run_id": "", "progress": {}, "artifacts": [], "error": None, "control": "run"}.items():
            db.execute("INSERT INTO meta VALUES (?,?)", (k, json.dumps(v, ensure_ascii=False)))


def metadata(folder):
    with connect(folder) as db:
        return {r["key"]: json.loads(r["value"]) for r in db.execute("SELECT * FROM meta")}


def update(folder, **values):
    with connect(folder) as db:
        for k, v in values.items():
            db.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", (k, json.dumps(v, ensure_ascii=False)))


@contextmanager
def worker_lock(folder):
    """OS-owned lock is released even if a worker crashes; no PID reuse race."""
    f = open(Path(folder) / "worker.lock", "a+b")
    f.seek(0, 2)
    if f.tell() == 0:
        f.write(b"0")
        f.flush()
    f.seek(0)
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        raise RuntimeError("Worker already active")
    try:
        yield
    finally:
        f.seek(0)
        if os.name == "nt":
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        f.close()


def is_live(folder):
    try:
        with worker_lock(folder):
            return False
    except RuntimeError:
        return True


TOKEN_RE = re.compile(r"\{v\d+\}|</?(?:style|b\d*|code)(?:\s[^>]*)?>|\[\[[^\]\n]+\]\]|%%[^%\n]+%%|%[sd]|\{[A-Za-z_]\w*\}")


def contract_for(prompt, kind):
    if prompt.lstrip().startswith("You are an expert multilingual terminologist."):
        return {"format": "terms"}
    marker = "\n## Here is the input:\n\n"
    if marker in prompt:
        try:
            entries = json.loads(prompt.rsplit(marker, 1)[1].strip())
            if isinstance(entries, list) and all(isinstance(x, dict) and "id" in x and "input" in x for x in entries):
                return {"format": "paragraphs", "entries": entries}
        except ValueError:
            pass
    marker = "Now translate the following text:"
    if marker in prompt:
        return {"format": "text", "input": prompt.split(marker, 1)[1].strip()}
    if kind == "text":
        return {"format": "text", "input": prompt.split("\n\nInput:\n", 1)[-1].strip()}
    # Unknown upstream prompt formats must be inspected, never guessed as JSON.
    return {"format": "raw"}


def check_tokens(source, target):
    if Counter(TOKEN_RE.findall(source)) != Counter(TOKEN_RE.findall(target)):
        raise ValueError("Formula/style placeholders do not match the source")
    # Preserve style nesting, allowing ordinary words to move around the tags.
    tags = re.compile(r"</?(?:style|b\d*|code)(?:\s[^>]*)?>")
    if tags.findall(source) != tags.findall(target):
        raise ValueError("Style tag order changed")


def validate_response(contract, response):
    if not isinstance(response, str) or not response.strip():
        raise ValueError("Response must be a non-empty string")
    fmt = contract["format"]
    if fmt == "text":
        check_tokens(contract["input"], response)
    elif fmt in ("terms", "paragraphs"):
        try:
            parsed = json.loads(response)
        except ValueError as e:
            raise ValueError("Return JSON only, without Markdown fences") from e
        if not isinstance(parsed, list):
            raise ValueError("Expected a JSON array")
        if fmt == "terms":
            if not all(isinstance(x, dict) and set(x) == {"src", "tgt"} and all(isinstance(x[k], str) and x[k].strip() for k in ("src", "tgt")) for x in parsed):
                raise ValueError("Each term must have non-empty src and tgt strings")
        else:
            inputs = contract["entries"]
            if len(parsed) != len(inputs):
                raise ValueError("Paragraph count changed")
            for src, dst in zip(inputs, parsed):
                if not isinstance(dst, dict) or set(dst) != {"id", "output"} or type(dst["id"]) is not type(src["id"]) or dst["id"] != src["id"]:
                    raise ValueError("Paragraph IDs/order changed; return id and output only")
                if not isinstance(dst["output"], str) or (src["input"].strip() and not dst["output"].strip()):
                    raise ValueError("Missing translated paragraph")
                check_tokens(src["input"], dst["output"])
    return response.strip()


def enqueue(folder, prompt, kind, run_id):
    rid = hashlib.sha256((kind + "\0" + prompt).encode()).hexdigest()
    contract = contract_for(prompt, kind)
    with connect(folder) as db:
        db.execute("INSERT OR IGNORE INTO requests VALUES (?,?,?,?,NULL,?,?)", (rid, kind, prompt, json.dumps(contract, ensure_ascii=False), time.time(), run_id))
        db.execute("UPDATE requests SET run_id=? WHERE id=?", (run_id, rid))
    return rid


def response_for(folder, rid):
    with connect(folder) as db:
        return db.execute("SELECT response FROM requests WHERE id=?", (rid,)).fetchone()[0]


def pending(folder, limit=4, max_chars=24000):
    meta = metadata(folder)
    with connect(folder) as db:
        rows = db.execute("SELECT * FROM requests WHERE response IS NULL AND run_id=? ORDER BY created,id LIMIT ?", (meta["run_id"], limit)).fetchall()
    result, size = [], 0
    for r in rows:
        if result and size + len(r["prompt"]) > max_chars:
            break
        c = json.loads(r["contract"])
        item = {"request_id": r["id"], "kind": r["kind"], "response_format": c["format"], "prompt": r["prompt"]}
        result.append(item)
        size += len(r["prompt"])
    return result


def submit(folder, results):
    if not results or len(results) > 32:
        raise ValueError("Submit between 1 and 32 results")
    seen = set()
    with connect(folder) as db:
        db.execute("BEGIN IMMEDIATE")
        for item in results:
            rid = item["request_id"]
            if rid in seen:
                raise ValueError("Duplicate request ID in submission")
            seen.add(rid)
            row = db.execute("SELECT * FROM requests WHERE id=?", (rid,)).fetchone()
            if row is None:
                raise ValueError("Unknown request ID")
            response = validate_response(json.loads(row["contract"]), item["response"])
            if row["response"] is not None and row["response"] != response:
                raise ValueError("Request already has a different committed response")
            db.execute("UPDATE requests SET response=? WHERE id=?", (response, rid))
    return {"accepted": len(results)}


def counts(folder):
    run_id = metadata(folder)["run_id"]
    with connect(folder) as db:
        r = db.execute("SELECT COUNT(*) total, SUM(response IS NOT NULL) completed, SUM(response IS NULL AND run_id=?) pending FROM requests", (run_id,)).fetchone()
    return {k: r[k] or 0 for k in r.keys()}
