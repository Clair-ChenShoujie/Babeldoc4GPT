"""Cloud-native JSON file interface. stdout is data; engine diagnostics go to job logs."""
import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "vendor"), str(ROOT / "scripts")]
for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(variable, "2")
for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command")
    parser.add_argument("--args", help="UTF-8 JSON arguments file; stdin when omitted")
    parser.add_argument("--data", help="Stable task storage directory, e.g. /mnt/data/babeldoc-jobs")
    parser.add_argument("--out", help="Write JSON output here as well as stdout")
    args, extra = parser.parse_known_args()
    if args.data:
        os.environ["BABELDOC_WORK_DATA"] = str(Path(args.data).resolve())
    import store
    os.environ["BABELDOC_CACHE_DIR"] = str(store.data_root() / "engine-cache")
    os.environ["PDF2ZH_CACHE_DIR"] = str(store.data_root() / "pdf2zh-cache")
    os.environ["PDF2ZH_CONFIG_DIR"] = str(store.data_root() / "pdf2zh-config")
    if args.command == "worker":
        # Cloud tools may terminate the controller abruptly. Do not orphan a
        # translation process in the shared sandbox after SIGKILL of its parent.
        if sys.platform == "linux" and os.environ.get("BABELDOC_PARENT_PID"):
            import ctypes
            import signal
            if ctypes.CDLL(None).prctl(1, signal.SIGTERM, 0, 0, 0) != 0:
                raise RuntimeError("Cannot establish worker parent-death protection")
            if os.getppid() != int(os.environ["BABELDOC_PARENT_PID"]):
                sys.exit(130)
        from worker import main as work
        work(extra[0])
        return
    if extra:
        parser.error("Unknown arguments: " + " ".join(extra))
    try:
        value = json.loads(Path(args.args).read_text(encoding="utf-8-sig")) if args.args else json.load(sys.stdin)
        from service import dispatch
        result = dispatch(args.command, value)
        encoded = json.dumps(result, ensure_ascii=False, indent=2)
        if args.out:
            Path(args.out).write_text(encoded, encoding="utf-8")
        print(encoded)
    except Exception as exc:
        print(json.dumps({"error": type(exc).__name__, "message": str(exc)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
