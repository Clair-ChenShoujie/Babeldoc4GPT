from __future__ import annotations

import json
import logging
import os
import shutil
import threading
import time
import uuid
from pathlib import Path

import store

ROOT = Path(__file__).resolve().parents[1]


class StopWork(BaseException):
    """Never let an upstream translation-error fallback swallow cancellation."""


def prepare_engine():
    os.environ["BABELDOC_CACHE_DIR"] = str(store.data_root() / "engine-cache")
    os.environ["PDF2ZH_CACHE_DIR"] = str(store.data_root() / "pdf2zh-cache")
    os.environ["PDF2ZH_CONFIG_DIR"] = str(store.data_root() / "pdf2zh-config")
    import babeldoc.const as const
    cache = store.data_root() / "engine-cache"
    cache.mkdir(parents=True, exist_ok=True)
    asset_root = Path(os.environ.get("BABELDOC_ASSETS", ROOT / "assets"))
    for directory in asset_root.iterdir() if asset_root.exists() else []:
        if directory.is_dir():
            dest = cache / directory.name
            dest.mkdir(exist_ok=True)
            for source in directory.rglob("*"):
                if source.is_file():
                    target = dest / source.relative_to(directory)
                    if not target.exists() or target.stat().st_size != source.stat().st_size:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source, target)
    const.CACHE_FOLDER = cache
    const.TIKTOKEN_CACHE_FOLDER = cache / "tiktoken"
    os.environ["TIKTOKEN_CACHE_DIR"] = str(const.TIKTOKEN_CACHE_FOLDER)
    # Avoid visible child PowerShell windows in the upstream CPU probe.
    if os.name == "nt":
        import joblib.externals.loky.backend.context as loky
        loky.physical_cores_cache = os.cpu_count()


def make_settings(config, folder):
    from pdf2zh_next.config.model import SettingsModel
    api = config.get("api") or {}
    engine = {"translate_engine_type": "OpenAI", "openai_model": api.get("model", "chatgpt-work"), "openai_api_key": "conversation-mode-unused"}
    if config["mode"] == "api":
        env_name = api.get("key_env", "BABELDOC_API_KEY")
        key = os.environ.get(env_name)
        if not key:
            raise ValueError(f"API mode requires the environment variable {env_name}")
        engine.update(openai_api_key=key, openai_base_url=api.get("base_url"), openai_timeout="120")
    translation = dict(config.get("translation_options", {}))
    translation.update(lang_in=config["source_language"], lang_out=config["target_language"], output=str(folder / "output"))
    translation.setdefault("pool_max_workers", 4)
    translation.setdefault("term_pool_max_workers", 2)
    translation.setdefault("qps", 4)
    pdf = dict(config.get("pdf_options", {}))
    if config.get("pages"):
        pdf["pages"] = config["pages"]
    settings = SettingsModel.model_validate({"translate_engine_settings": engine, "translation": translation, "pdf": pdf})
    settings.validate_settings()
    return settings


def main(job_id):
    folder = store.job_dir(job_id)
    try:
        with store.worker_lock(folder):
            run(folder)
    except RuntimeError as exc:
        if str(exc) != "Worker already active":
            raise


def run(folder):
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    run_id = uuid.uuid4().hex
    store.update(folder, status="preparing", run_id=run_id, error=None, progress={}, artifacts=[], pid=os.getpid(), heartbeat=time.time())
    config = store.metadata(folder)["config"]
    stop = threading.Event()
    engine_config = None

    def heartbeat():
        while not stop.wait(2):
            store.update(folder, heartbeat=time.time())
            if store.metadata(folder)["control"] != "run" and engine_config:
                engine_config.cancel_translation()

    threading.Thread(target=heartbeat, daemon=True).start()
    try:
        prepare_engine()
        from pdf2zh_next.translator.base_translator import BaseTranslator
        from pdf2zh_next.translator.base_rate_limiter import BaseRateLimiter
        import pdf2zh_next.high_level as upstream

        class NoLimit:
            def wait(self, *args, **kwargs):
                pass

        class ConversationTranslator(BaseTranslator):
            name = "chatgpt_work"
            model = "current-conversation"

            def __init__(self, settings):
                super().__init__(settings, NoLimit())
                # Requests/results live in the job DB, not shared across documents.
                self.ignore_cache = True

            def request(self, prompt, kind):
                rid = store.enqueue(folder, prompt, kind, run_id)
                last_activity = time.monotonic()
                while True:
                    if store.metadata(folder)["control"] != "run":
                        raise StopWork()
                    response = store.response_for(folder, rid)
                    if response is not None:
                        return response
                    if time.monotonic() - last_activity > 1800:
                        store.update(folder, control="pause")
                        raise StopWork()
                    time.sleep(0.2)

            def do_translate(self, text, rate_limit_params=None):
                return self.request(self.prompt(text)[0]["content"], "text")

            def do_llm_translate(self, text, rate_limit_params=None):
                return None if text is None else self.request(text, "llm")

        settings = make_settings(config, folder)
        if config["mode"] == "conversation":
            translator = ConversationTranslator(settings)
            upstream.get_translator = lambda _: translator
            upstream.get_term_translator = lambda _: translator
        engine_config = upstream.create_babeldoc_config(settings, folder / "input.pdf")
        # This setting exists upstream but pdf2zh's config converter omits it.
        if "save_auto_extracted_glossary" in config.get("translation_options", {}):
            engine_config.save_auto_extracted_glossary = settings.translation.save_auto_extracted_glossary
        engine_config.working_dir = folder / "working"
        engine_config.working_dir.mkdir(exist_ok=True)
        engine_config.conversation_cache_dir = folder / "phase-cache"
        engine_config.use_rich_pbar = False
        store.update(folder, status="running")

        from babeldoc.format.pdf.high_level import do_translate, get_translation_stage
        from babeldoc.progress_monitor import ProgressMonitor

        def report(**event):
            store.update(folder, progress={k: v for k, v in event.items() if k in ("stage", "stage_progress", "stage_current", "stage_total", "overall_progress")})

        # Upstream on_finish invokes finish_callback even on normal teardown
        # when a cancellation event is present. The synchronous return/exception
        # below is authoritative; this callback must still be callable.
        with ProgressMonitor(get_translation_stage(engine_config), progress_change_callback=report, finish_callback=lambda **event: None, cancel_event=threading.Event(), report_interval=0.5) as monitor:
            result = do_translate(monitor, engine_config)
        if store.metadata(folder)["control"] != "run":
            raise StopWork()
        if store.counts(folder)["pending"]:
            raise RuntimeError("Engine finished with unanswered model requests; refusing partial output")
        files = []
        for name in ("mono_pdf_path", "dual_pdf_path", "no_watermark_mono_pdf_path", "no_watermark_dual_pdf_path", "auto_extracted_glossary_path"):
            path = getattr(result, name, None)
            if path and Path(path).is_file() and str(Path(path).resolve()) not in [x["path"] for x in files]:
                files.append({"kind": name, "path": str(Path(path).resolve()), "size": Path(path).stat().st_size})
        if not any(f["path"].lower().endswith(".pdf") for f in files):
            raise RuntimeError("BabelDOC finished without a PDF artifact")
        store.update(folder, artifacts=files, status="completed", progress={"stage": "Completed", "overall_progress": 100})
    except BaseException as exc:
        control = store.metadata(folder)["control"]
        if control in ("pause", "cancel", "yield") or isinstance(exc, StopWork):
            store.update(folder, status="cancelled" if control == "cancel" else ("awaiting_translation" if control == "yield" else "paused"))
        else:
            logging.exception("Translation worker failed")
            store.update(folder, status="failed", error=f"{type(exc).__name__}: {exc}")
    finally:
        stop.set()
        store.update(folder, heartbeat=time.time())
