"""Portable data-only checkpoints; imported archives never provide executable code."""
import hashlib
import json
import re
import shutil
import time
import uuid
import zipfile
from pathlib import Path

import store


def export_checkpoint(job_id, destination):
    folder = store.job_dir(job_id)
    if store.is_live(folder):
        raise ValueError("Finish the current advance step before exporting a checkpoint")
    meta = store.metadata(folder)
    with store.connect(folder) as db:
        rows = [dict(x) for x in db.execute("SELECT * FROM requests")]
    config = dict(meta["config"])
    config["output_directory"] = None
    config["translation_options"] = dict(config["translation_options"])
    glossaries = list((folder / "glossaries").glob("*.csv"))
    config["translation_options"].pop("glossaries", None)
    state = {"format": "babeldoc-cloud-checkpoint", "version": 1, "engine": "0.6.2", "config": config, "run_id": meta["run_id"], "requests": rows, "glossaries": [p.name for p in glossaries]}
    target = Path(destination).resolve()
    if target.exists():
        raise ValueError("Checkpoint destination already exists; choose a new filename")
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as out:
        out.writestr("state.json", json.dumps(state, ensure_ascii=False))
        out.write(folder / "input.pdf", "input.pdf")
        for path in glossaries:
            out.write(path, "glossaries/" + path.name)
    return {"checkpoint": str(target), "size": target.stat().st_size, "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "note": "Includes source PDF and translations; upload this file to a later cloud task to recover."}


def import_checkpoint(checkpoint_path, allow_api=False):
    with zipfile.ZipFile(checkpoint_path) as source:
        if sum(x.file_size for x in source.infolist()) > 1024 * 1024 * 1024:
            raise ValueError("Checkpoint exceeds 1 GiB expanded size")
        names = source.namelist()
        if len(set(names)) != len(names) or any(not (n in ("state.json", "input.pdf") or re.fullmatch(r"glossaries/[0-9]+\.csv", n)) for n in names):
            raise ValueError("Unexpected or unsafe checkpoint entry")
        state = json.loads(source.read("state.json"))
        data = source.read("input.pdf")
        if state.get("format") != "babeldoc-cloud-checkpoint" or state.get("version") != 1 or state.get("engine") != "0.6.2":
            raise ValueError("Unsupported checkpoint format/engine")
        config = state["config"]
        if hashlib.sha256(data).hexdigest() != config["input_sha256"]:
            raise ValueError("Source PDF checksum mismatch")
        seen = set()
        for row in state["requests"]:
            expected = hashlib.sha256((row["kind"] + "\0" + row["prompt"]).encode()).hexdigest()
            if row["id"] != expected or expected in seen:
                raise ValueError("Invalid/duplicate request fingerprint")
            seen.add(expected)
            contract = store.contract_for(row["prompt"], row["kind"])
            row["contract"] = json.dumps(contract, ensure_ascii=False)
            if row["response"] is not None:
                store.validate_response(contract, row["response"])
        # Do not restore executable instructions or absolute filesystem paths.
        if config.get("mode") not in ("conversation", "api"):
            raise ValueError("Unknown translation mode")
        if config.get("mode") == "api" and not allow_api:
            raise ValueError("This checkpoint uses a paid API. Restore only with explicit user authorization and allow_api=true")
        if set(config.get("api") or {}) - {"model", "base_url", "key_env"}:
            raise ValueError("Invalid API configuration")
        config["output_directory"] = None
        config["translation_options"].pop("glossaries", None)
        if set(config["translation_options"]) & {"output", "rpc_doclayout"}:
            raise ValueError("Checkpoint contains a filesystem/network override")
        job_id = uuid.uuid4().hex
        folder = store.data_root() / "jobs" / job_id
        folder.mkdir(parents=True)
        (folder / "input.pdf").write_bytes(data)
        paths = []
        for name in state.get("glossaries", []):
            if not re.fullmatch(r"[0-9]+\.csv", name):
                raise ValueError("Invalid glossary filename")
            target = folder / "glossaries" / name
            target.parent.mkdir(exist_ok=True)
            target.write_bytes(source.read("glossaries/" + name))
            paths.append(str(target))
        if paths:
            config["translation_options"]["glossaries"] = ",".join(paths)
    store.initialize(folder, config)
    store.update(folder, run_id=state["run_id"], status="ready")
    with store.connect(folder) as db:
        for row in state["requests"]:
            db.execute("INSERT INTO requests VALUES (?,?,?,?,?,?,?)", tuple(row[k] for k in ("id", "kind", "prompt", "contract", "response", "created", "run_id")))
    from service import status
    return status(job_id)
